# Computer-Graphics-C-
Graphical or GUI based  code in "C" programming language.....

There are two folder in this repository....

First folder contains 2D_graphics_programs like:-
Translation
Rotation
scaling
Reflection
Shearing

Second folder contains 3D_graphics_programs like:-
Translation
Rotation
Scaling


Output of the program is in .jpg formate...
